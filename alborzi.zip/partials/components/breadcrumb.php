<div class="my-6 md:px-10 py-6 md:max-px-4 bg-noise bg-primary-80 text-neutral-400 [&_.last]:text-neutral-700 [&_p]:flex [&_p]:items-center [&_p]:gap-2  ">
    <div class="container [&_.rank-math-breadcrumb]:overflow-auto ">
        <?php if (function_exists('rank_math_the_breadcrumbs')) rank_math_the_breadcrumbs(); ?>
    </div>
</div>