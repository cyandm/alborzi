<div id="preloader" class="fixed inset-0 flex items-center justify-center bg-white z-50">
    <img src="<?php echo CYN_THEME_DIR . '/assets/img/preloader-1.jpg' ?>" class="preload-image opacity-100 transition-opacity duration-1000 pointer-events-none absolute">
    <img src="<?php echo CYN_THEME_DIR . '/assets/img/preloader-2.jpg' ?>" class="preload-image opacity-0 transition-opacity duration-1000 pointer-events-none absolute">
    <img src="<?php echo CYN_THEME_DIR . '/assets/img/preloader-3.jpg' ?>" class="preload-image opacity-0 transition-opacity duration-1000 pointer-events-none absolute">
</div>
