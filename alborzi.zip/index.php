<?php defined( 'ABSPATH' ) || exit; ?>

this is index.php